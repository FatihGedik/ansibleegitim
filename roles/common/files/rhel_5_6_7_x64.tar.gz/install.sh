#!/bin/sh
# ==========================================================================================
# SolarWinds Agent offline installer
# Usage: Switch to this script's directory and execute it without parameters
# ------------------------------------------------------------------------------------------
# Exit codes:
# 0 ... success (no error was detected)

# unknown package type (looks like installation package is none of rpm or deb package)
ERROR_UNKNOW_PACKAGE_TYPE=1

# installation package was not found
ERROR_INST_PKG_NOT_FOUND=4

# there was found more than one installation package
ERROR_INST_PKG_NOT_UNIQUE=5

# service command was not found
ERROR_SERVICE_CMD_NOT_FOUND=6

# other agent is already installed
ERROR_OTHER_AGENT_INSTALLED=7

# package command (rpm or dpkg) not found
ERROR_PKG_COMMAND_NOT_FOUND=8

# cannot create temporary directory
ERROR_CANNOT_CREATE_TMP_DIR=9

# command tr not found
ERROR_TR_COMMAND_NOT_FOUND=10

# command wc not found
ERROR_WC_COMMAND_NOT_FOUND=11

# command base64 not found
ERROR_BASE64_COMMAND_NOT_FOUND=12

# package installation error
ERROR_INSTALLATION=13

# agent initialization failed
ERROR_INITIALIZATION=14

# agent start failed
ERROR_START=15

# unknown option given on command line
ERROR_UNKNOWN_OPTION=126

# internal error
ERROR_INTERNAL=127

# ------------------------------------------------------------------------------------------
# Environment variables used by this script:
# DEBUG ... when not empty, script dumps lot of debugging informations to stderr
#
# In some environments can be missing some important commands. In case of autodetection
# of such commands fails, they may be specified with dedicated environment variables.
# Content of such variable is always used with highest priority (e.g. no search for command
# is performed). Following environment variables/commands are supported:
# CMD_WHICH .... for 'which' command
# CMD_MKTEMP ... for 'mktemp' command
# CMD_RPM ...... for 'rpm' command
# CMD_DPKG ..... for 'dpkg' command
# CMD_TR ....... for 'tr' command
# CMD_WC ....... for 'wc' command
# CMD_BASE64 ... for 'base64 -d -i -' command (must read stdin and write to stdout)
# ==========================================================================================

debug()
{
    [ "${DEBUG}" != "" ]
}

debug_msg()
{
    if debug; then
        >&2 echo "$@"
        if [ "${INST_LOG}" != "" ]; then
            echo "$@" >> "${INST_LOG}"
        fi
    fi
}

show_help()
{
    >&2 echo "SolarWinds Orion Agent offline installer"
    >&2 echo "Usage:"
    >&2 echo "  switch to directory containing this script and execute it without parameters:"
    >&2 echo "  ./install.sh"
    >&2 echo
    >&2 echo "Additional options:"
    >&2 echo "  -h"
    >&2 echo "  --help ....... show this help"
    >&2 echo
    >&2 echo "  -k"
    >&2 echo "  --keep-log ... do not delete installation log even if installer succeeds"
    >&2 echo
}

parse_options()
{
    debug_msg "parse_options: $@"

    # Set defaults
    OPT_KEEP_LOG=

    while [ $# -gt 0 ]; do
        CMD="$1"
        shift

        case "${CMD}" in
            -h|--help)
                show_help
                exit 0
                ;;

            -k|--keep-log)
                OPT_KEEP_LOG=1
                ;;

            *)
                >&2 echo "Unknown option '${CMD}'"
                >&2 echo
                show_help
                exit $ERROR_UNKNOWN_OPTION
        esac
    done

    debug_msg "parse_options: done"
    debug_msg "OPT_KEEP_LOG='${OPT_KEEP_LOG}'"
    debug_msg "----------------------------------------"
}

cleanup()
{
    debug_msg "Cleanup"
    if [ "${OPT_KEEP_LOG}" = "" ] && [ "${TMP_DIR}" != "" ]; then
        rm -Rf "${TMP_DIR}" >&2
    else
        >&2 echo "Installation log is in '${INST_LOG}'"
    fi
}

set_environment()
{
    if debug; then
        DEBUG_REDIRECTION=""
    else
        DEBUG_REDIRECTION="2>/dev/null"
    fi

    # Add additional paths where to search for commands - they may differ according to OS
    WELL_KNOWN_PATHS=". /bin /usr/bin /usr/sbin /sbin /usr/local/bin /usr/local/sbin"
    UNAME_RESULT=`uname`
    case "${UNAME_RESULT}" in
        [aA][iI][xX])
            WELL_KNOWN_PATHS="${WELL_KNOWN_PATHS} /usr/linux/bin /opt/freeware/bin"
        ;;
    esac
    debug_msg "Setting WELL_KNOWN_PATHS for '${UNAME_RESULT}' to '${WELL_KNOWN_PATHS}'"

    # Check for which command - here cannot be used find_command function, because it uses CMD_WHICH
    if [ "${CMD_WHICH}" != "" ]; then
        debug_msg "CMD_WHICH used from environment: '${CMD_WHICH}'"
    else
        CMD_WHICH=`/bin/sh -c "which --skip-alias which ${DEBUG_REDIRECTION}"`
        if [ "$?" = "0" ]; then
            # Which was found and supports parameter --skip-alias
            CMD_WHICH="which --skip-alias"
        else
            # Which was either not found or does not support --skip-alias parameter, retry without options
            CMD_WHICH=`/bin/sh -c "which which ${DEBUG_REDIRECTION}"`
            if [ "${CMD_WHICH}" = "" ]; then
                # No which was found - use own simplified version
                CMD_WHICH=local_which
            fi
        fi
    fi

    # Check for mktemp command. local_mktemp_dir supports only creating of temporary directory in /tmp, which is enough
    if [ "${CMD_MKTEMP}" != "" ]; then
        debug_msg "CMD_MKTEMP used from environment: '${CMD_MKTEMP}'"
    else
        CMD_MKTEMP=`find_command mktemp` || CMD_MKTEMP="local_mktemp_dir"
    fi

    # Check for rpm and dpkg. It is expected that only one of them is present - they are checked later only when needed.
    if [ "${CMD_RPM}" != "" ]; then
        debug_msg "CMD_RPM used from environment: '${CMD_RPM}'"
    else
        CMD_RPM=`find_command rpm`
    fi

    if [ "${CMD_DPKG}" != "" ]; then
        debug_msg "CMD_DPKG used from environment: '${CMD_DPKG}'"
    else
        CMD_DPKG=`find_command dpkg`
    fi

    # Check for tr command. It is needed only when standard which command is not found and we are searching for command without path,
    # so the result is not checked here.
    if [ "${CMD_TR}" != "" ]; then
        debug_msg "CMD_TR used from environment: '${CMD_TR}'"
    else
        CMD_TR=`find_command tr`
    fi

    # Check for wc command
    if [ "${CMD_WC}" != "" ]; then
        debug_msg "CMD_WC used from environment: '${CMD_WC}'"
    else
        CMD_WC=`find_command wc` || { >&2 echo "Command 'wc' not found."; exit ${ERROR_WC_COMMAND_NOT_FOUND}; }
    fi

    # Check for working base64 decoding command (it must accept stdin for input and write its output to stdout)
    if [ "${CMD_BASE64}" != "" ]; then
        debug_msg "CMD_BASE64 used from environment: '${CMD_BASE64}'"
    else
        check_base64 "`find_command base64`" -d -i -
        if [ "${CMD_BASE64}" = "" ]; then        
            check_base64 local_base64_decode
            if [ "${CMD_BASE64}" = "" ]; then
                >&2 echo "Command 'base64' not found."
                exit ${ERROR_BASE64_COMMAND_NOT_FOUND}
            fi
        fi
    fi

    # -----------------------------------------------------------------------------------------------------------
    
    # Create temporary directory where are extracted embedded files
    TMP_DIR=`"${CMD_MKTEMP}" -d`
    if [ "${TMP_DIR}" = "" ]; then
        debug_msg "mktemp returned empty result"
        exit ${ERROR_CANNOT_CREATE_TMP_DIR}
    fi

    # Set paths to some used files
    DATA_DIR="./data"

    CA_CERT_FILE="${TMP_DIR}/ca_cert.crt"
    PROV_CERT_FILE="${TMP_DIR}/provisioning.pfx"
    INI_FILE="${TMP_DIR}/SolarWindsAgent.ini"
    
    INST_LOG="${TMP_DIR}/swiagent-install.log"

    SWI_AGENT_AID="/opt/SolarWinds/Agent/bin/swiagentaid.sh"
}

# Try to find command in PATH or in any directory given by $2, $3, ...
# $1 ... command to search for
# rest of parameters
find_command_x()
{
    # Command to find
    CMD="$1"
    shift

    # First try to find it in current PATH
    debug_msg "find_command_x: /bin/sh -c \"${CMD_WHICH} \\\"${CMD}\\\" ${DEBUG_REDIRECTION}\""
    RES=`/bin/sh -c "${CMD_WHICH} \"${CMD}\" ${DEBUG_REDIRECTION}"`
    if [ "${RES}" != "" ]; then
        debug_msg "find_command_x: Found ${RES}"
        echo "${RES}"
        return 0
    fi

    # Try to find it in additional paths given as subsequent parameters
    while [ "$#" != "0" ]; do
        debug_msg "find_command_x: /bin/sh -c \"${CMD_WHICH} \\\"$1/${CMD}\\\" ${DEBUG_REDIRECTION}\""
        RES=`/bin/sh -c "${CMD_WHICH} \"$1/${CMD}\" ${DEBUG_REDIRECTION}"`
        if [ "${RES}" != "" ]; then
            debug_msg "find_command_x: Found ${RES}"
            echo "${RES}"
            return 0
        fi
        shift
    done

    debug_msg "find_command_x: ${CMD} not found"
    return 1
}

# Try to find command in PATH, WELL_KNOWN_PATHS and additional directories given as $2, $3, ...
# $1 ... command to search for
# rest of parameters ... additional search paths
# It is just a wrapper for find_command_x adding ${WELL_KNOWN_PATHS}
find_command()
{
    if [ "$#" = "0" ]; then
        >&2 echo "No arguments passed to find_command function"
        >&2 echo "Usage: find_command command [alternate-dir1] [alternate-dir2] ... [alternate-dirn]"
        exit ${ERROR_INTERNAL}
    fi

    # Command to find
    CMD="$1"
    shift

    find_command_x "${CMD}" ${WELL_KNOWN_PATHS} "$@"
}

# Own implementation of which command - it is used only when no which command is found
local_which()
{
    if [ "$#" = "0" ]; then
        >&2 echo "No arguments passed to local_which function"
        >&2 echo "Usage: local_which command"
        exit ${ERROR_INTERNAL}
    fi

    CMD="$1"

    debug_msg "local_which: CMD='${CMD}'"

    case "${CMD}" in
        */*)# Command contains PATH delimiter - consider it full path or relative path
            if [ -x "${CMD}" ]; then
                echo "${CMD}"
                return 0
            fi
            return 1
        ;;

        *)  # No PATH delimiter, try to find command in directories specified by PATH env variable
            if [ "${CMD_TR}" = "" ]; then
                >&2 echo "Command 'tr' not found."
                exit ${ERROR_TR_COMMAND_NOT_FOUND}
            fi
            
            echo ${PATH} | "${CMD_TR}" ':' '\n' | while read dir; do
                if [ -x "${dir}/${CMD}" ]; then
                    echo "${dir}/${CMD}"
                    break
                fi
            done
        ;;
    esac
}

# Own implementation of "mktemp -d" - it is used only when no mktemp is found
local_mktemp_dir()
{
    REMAINING_ATTEMPTS=20
    while true; do
        TEMP_NAME="/tmp/swiagent-${RANDOM}-$$"
        if [ ! -e "${TEMP_NAME}" ] && mkdir "${TEMP_NAME}" >/dev/null; then
            echo ${TEMP_NAME}
            return
        fi
        
        REMAINING_ATTEMPTS=`expr ${REMAINING_ATTEMPTS} - 1`
        if [ "${REMAINING_ATTEMPTS}" -eq "0" ]; then
            >&2 echo "Fatal: Cannot create temporary directory"
            exit ${ERROR_CANNOT_CREATE_TMP_DIR}
        fi
    done
}

# Own implementation of "base64 -d" - it is used only when no working base64 is found and when perl with module MIME::Base64 is available
local_base64_decode()
{
    perl -MMIME::Base64 -e 'undef $\; print decode_base64(<>);'
}

test_installed_rpm()
{
    if [ "${CMD_RPM}" = "" ]; then
        >&2 echo "Cannot find rpm command"
        exit ${ERROR_PKG_COMMAND_NOT_FOUND}
    fi
    "${CMD_RPM}" -q "$1"
}

test_installed_deb()
{
    if [ "${CMD_DPKG}" = "" ]; then
        >&2 echo "Cannot find dpkg command"
        exit ${ERROR_PKG_COMMAND_NOT_FOUND}
    fi
    "${CMD_DPKG}" -s "$1" | grep -e 'Status: .* installed'
}

# Sample text for checking base64 decoder works correctly
DECODED_BASE64_SAMPLE="base64 test"
ENCODED_BASE64_SAMPLE="YmFzZTY0IHRlc3Q="

check_base64()
{
    debug_msg "check_base64: $@"

    if [ "$1" = "" ]; then
        debug_msg "check_base64: empty command"
        return 1
    fi

    # Try to decode sample and compare it with expected value
    if [ "`echo \"${ENCODED_BASE64_SAMPLE}\" | \"$@\"`" = "${DECODED_BASE64_SAMPLE}" ]; then
        CMD_BASE64="$@"
        return 0
    fi

    # Decoder did not return expected result
    CMD_BASE64=""
    return 1
}

main()
{
    if debug; then
        >&2 pwd
        >&2 ls -la
        >&2 echo
    fi

    debug_msg "SWI_AGENT_AID=${SWI_AGENT_AID}"

    INSTALL_PACKAGE=`find "${DATA_DIR}" -name '*.rpm' -print; find "${DATA_DIR}" -name '*.deb' -print`
    debug_msg "Install package: ${INSTALL_PACKAGE}"

    if [ "${INSTALL_PACKAGE}" = "" ]; then
        >&2 echo "Cannot find any install package."
        exit ${ERROR_INST_PKG_NOT_FOUND}
    fi

    # This works only when DATA_DIR and package name does not contain any new-line characters
    PACKAGE_COUNT=`echo "${INSTALL_PACKAGE}" | "${CMD_WC}" -l`

    debug_msg "Found ${PACKAGE_COUNT} package(s)"

    if [ "${PACKAGE_COUNT}" -ne "1" ]; then
        >&2 echo "Cannot determine which package from
${INSTALL_PACKAGE}
should be installed - only one install package is expected"
        exit ${ERROR_INST_PKG_NOT_UNIQUE}
    fi

    PACKAGE=`basename "${INSTALL_PACKAGE}"`
    debug_msg "PACKAGE=${PACKAGE}"

    PACKAGE_TYPE=${PACKAGE##*.}
    debug_msg "PACKAGE_TYPE=${PACKAGE_TYPE}"

    if [ "${PACKAGE_TYPE}" = "rpm" ]; then
        INSTALL="${CMD_RPM} -Uvh"
    elif [ "${PACKAGE_TYPE}" = "deb" ]; then
        INSTALL="${CMD_DPKG} -i"
    else
        >&2 echo "Unknown package type ${PACKAGE_TYPE}"
        exit ${ERROR_UNKNOW_PACKAGE_TYPE}
    fi
    debug_msg "INSTALL=${INSTALL}"

    if "test_installed_${PACKAGE_TYPE}" swiagent >>"${INST_LOG}" 2>&1; then
        >&2 echo "Cannot install agent: other agent is already installed"
        RES=${ERROR_OTHER_AGENT_INSTALLED}
    else
        if [ "`id -u 2>/dev/null`" = "0" ]; then
            >&2 echo "Starting the installation."
            ESH='/bin/sh'
        else
            >&2 echo "Starting the installation. You will be prompted for root credentials."
            ESH='su'
        fi

        INSTALL_CMD=`cat <<END_OF_INSTALL_CMD
        echo "Installing package '${INSTALL_PACKAGE}'"
        ${INSTALL} "${INSTALL_PACKAGE}"
        ec=\\\$?
        if [ "\\\$ec" != "0" ]; then
            echo "Package installation failed with exit code '\\\$ec'"
            exit $ERROR_INSTALLATION
        fi
        
        echo "Initializing agent"
        ${SWI_AGENT_AID} init /installcert /s iniFile="${INI_FILE}" ca_cert="${CA_CERT_FILE}" cert="${PROV_CERT_FILE}"
        ec=\\\$?
        if [ "\\\$ec" != "0" ]; then
            echo "Agent initialization failed with exit code '\\\$ec'"
            exit $ERROR_INITIALIZATION
        fi

        WAIT_COUNTER=6
        while [ "\\\${WAIT_COUNTER}" -gt "0" ]; do
            sleep 5
            echo "Checking status of agent service"
            ${SWI_AGENT_AID} status swiagentd
            if [ "\\\$?" = "0" ]; then
                echo "Agent service is running - installation is finished"
                exit 0
            fi

            WAIT_COUNTER=\\\`expr \\\${WAIT_COUNTER} - 1\\\`
            echo "Agent service not yet running, waiting will continue (\\\${WAIT_COUNTER} attempts remaining)"
        done

        echo "Agent service did not start yet - force to start it"
        ${SWI_AGENT_AID} start swiagentd
        ec=\\\$?
        if [ "\\\$ec" != "0" ]; then
            echo "Start of agent service failed with exit code '\\\$ec'"
            exit $ERROR_START
        fi
END_OF_INSTALL_CMD
`

        debug_msg "${ESH} -c \"${INSTALL_CMD}\""

        ${ESH} -c "( ${INSTALL_CMD} ) >>\"${INST_LOG}\" 2>&1"
        RES="$?"
    fi

    if [ "${RES}" = "0" ]; then
        >&2 echo "Installation finished"
        debug && ps -ef | grep Solar | grep -v grep >&2
    else
        >&2 echo "Installation failed (${RES})"
        OPT_KEEP_LOG=1
    fi

    return "${RES}"
}

parse_options "$@"
set_environment
trap cleanup EXIT

${CMD_BASE64} > "${CA_CERT_FILE}" <<END_OF_CA_CERT
MIIDJTCCAg2gAwIBAgIQqoM6/ehPdI1NLBW2bg90+TANBgkqhkiG9w0BAQsFADAbMRkwFwYDVQQDExBTb2xhcldpbmRzLU9yaW9uMB4XDTE3MDQyNjA5MTg1N1oXDTM5MTIzMTIzNTk1OVowGzEZMBcGA1UEAxMQU29sYXJXaW5kcy1PcmlvbjCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMFcwYIdABxM5rLq7UT5fpqd6UNhCAoEdw+9O5dFgiYCpdWiXhlftlmEqYL95leHsVdpvSS3BTHugwZ9EfdqEO1iJ3lQzltnZM0ijkVNnvb9jvXyU96+2pIm7llGK2c1opt2O+798C0XzpEz+PyV+MyMqcl7DFfJIaGMeiExuGw1Ce3hCDRLiGC7de77J7Bf+JwWB5EXBhbGwdyW9LmWmuXLtUwztW3kiAXUzIplYiV1YA+dgr7g32OrumYAdoCRNM/ytBjQNkc1zbUSdgcQ+XH2C1iTfLZ6SIoIkWGkOPMN7tQ/G8oQZzlSeo4r/yE6V7ehghTomx/DG/Qw2/8c3RMCAwEAAaNlMGMwEwYDVR0lBAwwCgYIKwYBBQUHAwEwTAYDVR0BBEUwQ4AQ/5alAgZ8wK8aJRF8kCFTUaEdMBsxGTAXBgNVBAMTEFNvbGFyV2luZHMtT3Jpb26CEKqDOv3oT3SNTSwVtm4PdPkwDQYJKoZIhvcNAQELBQADggEBAG9JvywbBoiCLf5SRGr680ezPaCvt8WfYAdKtBcTDX1CErt0jpO8D1ghsQ0oxCU1fY01DjqcD97f6xiZkXwhm8ywB6bTYa/p7smifnwaROv9fLTqz+6b/Wj/qpQPTLNG6ZcfHfAuafuJDf1ibWHRksttf/bvKDmCdMkL/Jh3SBbmK9M8L7EYDKzTOX76m/BJToOrW5gN4MOKHnginAqjJ2uI/VJXU/cPX1xnLcaJfaKau7kpWCf0J6sVE/3qhoWwoZI43PTWNLMzrNZU0xTS+0pIZwCAufdK7ZXWtEVA1BU0+VTfiF85gQqRssoB4HKLRPgnzelTB390LDIZFYBcImU=
END_OF_CA_CERT

${CMD_BASE64} > "${PROV_CERT_FILE}" <<END_OF_CERT
MIINhwIBAzCCDUcGCSqGSIb3DQEHAaCCDTgEgg00MIINMDCCCMEGCSqGSIb3DQEHAaCCCLIEggiuMIIIqjCCCKYGCyqGSIb3DQEMCgECoIIHPjCCBzowHAYKKoZIhvcNAQwBAzAOBAig8eRZrSzIMwICB9AEggcY0VgLZOlwh7HbwlLRSgjr+cp1BKGE982+DZr9V+3scaH1v0ZVsBRj5zYnMeZ0xYsr7Du1BgVRN1k05o+q7SKpgAk3uSI3g5dxzTltzpy1tOFJ8xi0/Vg2xJT1jew3bLrchD90mcrinj0zRQARTB2Dfzi7M9RWkrsQOw64iPglaGAxcXhRc0uNdgJ57c8IBmlCjSb5/NCnvla/K2XWWQKubv6x3Y8CddzvSExEaVV+HZs/jyJFxKTvYfREeMsgPcSP/ERGtiEyuOVl1azJQZxRPqbksTgcBdPHkFiFu6vkIbXLjueUAPA0pU3wG1nSn6Q7/vbz6qx2GKEp+GDyf+LTf4Ve+hqbcn0HVy9jRc0t3olLLLKuZI3O4hgebSU+JOcGxB0e7B31JJCDjY+W7SBiZTw9wqlqeBAof4uNqT7M8vaqUmIPlL3FiJfC8M6ynbVABPE58+lkIh5UXhaQ4u0boj5xbSdB1FpAk3JW7B1ZySeTx39HIZyAmzVtSG6MKbVQVFQ7Tz9C/56Y1jOGwvTeyPwiY6an46L6cfAdZRjjBBC+kZJ45cQfmSHm/j7dD7y6AJ8oMwPGrMIdDpACQaYUpHRZ4DL+zQcIAfnsi2ltTKnkUyRJV+v0OqgmiS/WMTdGsPeKYXg22HdZQBsrM0JNci6hktU9J78RIPm1eiasPxVXwVwhhkukGjSB9IV1OWmXLmZph/9IvuVnDbEG/LL/h58rIESp3xoSYDbROuHYpKvl9BKOyvDEjwKC9F9om1MIhV9e8Lto0YnTceyKudYJyzLyqI9jNuHmFCC93uEPOH+0GGmxZQ1ZtbSxy6H1kQVBA1B+ahKWykzizS33GW/6NmGccQWm+vzUuxeg8CA5o06QiTIL7V1WB06Q6CJ6gDqnAc+xUmB9AyXzeGF6hvdO0duwN3BmaSkigU2j3sPzn0g7dd9IeAJavYGrnvN9J9Bp0WM4p2VWmnwcU/8798trzjy/SL+/1vxb+SSauUqRafQ4NSagdQEwbn71c50h70oZLERVAy7iTHU54YAFUDBZy0QyF1ili9KzHSa9oIj+G2IoOhbN5HRDy0YmxgyWugQMr85GgkyXn9yHE6xTcwsS6jAu0RoOnPM/7IqO8VvxavkWd4ZAZPWq2/o09J2gzg4uH0P1w73Piqj6pQR+o7O53orvO077bGpJ62Xy7Ht8KTP14+ucc2zjjJoQOmb9jTksi9y3zDoQLm7IYWx3yQ83nb22lsB/PAzuzUy7wfAsUg+W2qxlzfFPKGitK9BdhNCofJQaE/D9w7fQvp2UUc6BESsc8TbQWFoYoSrTXlGs7lDvTGWWHjhrpxHw1Ka2CanSab76/WFQJq/dVKD2I2Ay248BhMujM78S1e0hCQy9uQ/BKrUOr2H2XcL25/+a3XllwgP/UsIalQ3Ej5Ca84gQxFqGO7MjUjgRTMaeAFbPm068qnq8HiM41a4rCInyeQv0CzIK5u81qyqdmxymgeBhocGrIuaFq15lKTN86SksBoV0pSZBdoWNOOaJOyGGne61ILGRejoedGTf0O94mWE5PE23Z2AvC/sLrQsY2HKhnDTrRLiTbwk8bMUvXcEFuMwdGuUKNE7rBCXiRXCY5WtpZ0Okzpi83j+lqkthCROGJCr/dS3DUJtToXdJgA1xRY3d4SAbevvG/DWP+Q7bdlvVS6DFC4Zc5DOC9CkYFSUwXshYPM8cX7ZMmp2j6T+IopP6yi6zu4gDzyEYsIniNn5KEefI1Hc2mPNUqH44nN3FUO61hl2oLH95aSYSY34nJ9sHRTJb+46E0mbG9AlJ0hPuADM5ZX4oJ7dNgddZkmrlz2CZmAvE1TUuv8BgMBVi175urQpNJYbAoIHTVfkIvZelWhIJVUdlOv4rNbGdUGfxsBBGt3LO6vppQXGTGQojb94jWUFjRgpOvSiwhGFuj+mbtdH6qKi1tZmbbf9pyX0R421ubFbqvQhKa+X+oqqyHFzvLJ5wxstAbAcu2GlcyI7D9gkdt+RlNGOa9WnMDLbb0GRTmVXqqFq8zuXAlXYrdzTHsn5CHJUTspqggR6QNP1JCcLDb1y4nT68rA/NEAll2EXiGrYHYnulvZpfRxjR30i7h2bYr/M/1i1A7FxPAa4JYUGlIaNvrgXaMMRbKyXXmSlKHjLE2QtGKVC/4/3uzvNzSYCS1nHtAlRseEEiEPykcSHm1mdPpiaehFyFQsLP9HzTa8bjoqFkznVGSZYVPqRzzqQm4D2l8HEbETs6u877FUcLTJ0ZqHSxSaDvZf2CDJwXjuB8xhBRyEohfEvIfrfRH/grokeQ7RefvfSzVxsD4WDE1i5Pgjs0qGQiO3Lf6XrB+YvhVN7hOLb33r9MwSL5QAsy/FSb6CVKy13xFW9c6cfAqPR//AsKvKw0GQo5ZRcLKeGNF2WxxTGCAVMwDQYJKwYBBAGCNxECMQAwEwYJKoZIhvcNAQkVMQYEBAEAAAAwawYJKwYBBAGCNxEBMV4eXABNAGkAYwByAG8AcwBvAGYAdAAgAEUAbgBoAGEAbgBjAGUAZAAgAEMAcgB5AHAAdABvAGcAcgBhAHAAaABpAGMAIABQAHIAbwB2AGkAZABlAHIAIAB2ADEALgAwMIG/BgkqhkiG9w0BCRQxgbEega4AQwBOAD0AUwBvAGwAYQByAFcAaQBuAGQAcwAgAEEAZwBlAG4AdAAgAFAAcgBvAHYAaQBzAGkAbwBuACAALQAgADkAYQBkAGMANgA3ADgAYwAtADIAZABlADAALQA0ADMAZAA2AC0AOQA3ADQAOAAtADYANwA1ADAAMgAyAGYAMgA5ADEAMAAzACAAZQB3AEsAZQB5AEMAbwBuAHQAYQBpAG4AZQByAFQAZQBtAHAwggRnBgkqhkiG9w0BBwagggRYMIIEVAIBADCCBE0GCSqGSIb3DQEHATAcBgoqhkiG9w0BDAEGMA4ECEXwPA84PFQwAgIH0ICCBCCfPL9ipKrA6zxJ9Clw0G7UXz/VdjC15NTtUK4JZpTeqmvnUJi024M48OOorxHSpD+mlhg1YZhKcynl2R5cyzhIeUarSCMsdYiZtRRU9hLorc2hcI9fOxyvKGawveirF1BuiUBSTHLjH4Wsh6Z7bN6kP47nXTUt8tQiD3cUS4XgdSQkIIFhsLPomhjONYhM94oYMcoFQftgp17UFgL3JYbugvn6uOiC6Dy7Cp6cp/WgGRBEtHplC0U9u90mPU/WMMw5a5rv1HLCwZkxMS11Loq4ZLwD/n89Farw1aD7+kbo+jmBz4q2xylqcCiN9aXcfG9cMvRw1cVjPooW8yiyF+gS2nF5j45NVJWYrdgjs8wteIKo2EST5nL8RoODMKjLOHi/mHY+AhkhUFlSetMYlma9BQpxqCNOamW7mKV06Xvbbio1oBe4ppR/IToHeqw1MDh651mDVryJW5WhLTJtuJfBba5NOGHre9TbwyP0WAwspoT7yuNQVJdkYui5gNVBaGl8XFHzym6ucdEYHrU/LcSkNSF4MkOejZS0RLCH6hSYpmdYcFYJbQJo7TOaDYQGxIT/QNQLHq1dlghvZ3R/fTAbgPVNtXhZNBYZcG/HmC8DZ2U+YzEa9wl2oVOouffsrx/xaer3+BsktR2WCbpaZSAjGjsQk0zBa/KAkupHUzjixGHeRUuLP9IyHomqnaEbZ6p9QkbuzvzwFeHMYtkeUpojhC0JmSXWknl9DWMd4CMhDOUbb1ExInrmQor+DuZsJ6Szn62zIspHC70tbbmK3xz86JpuHTMHbjPnFHHqbc03aiqV9uc7OYPoe1gnuQlUtfZDsCPFyiO1VMQJywr5xotR3Yls1FMuXo+9hq1T4OjeqSzNKtr+8j7tetdBt0ezqPJEIr8uh01eQ/WQt+KmxliyPsfd9u+sqqlDTdDA97FBV8HtrpV1TxmRgBSeVKdrkydVaxbqRI2xRoRYnC+0Naw6yt/MKAT/29fT+XJWmgttI5SScDZC13+YLralO3xTUV51r/7NEorQ2ITwf8Kh6ytVBPPAjHoGOTXjfOKSsuiBHwIOYjZyQY+LOJO28+EEkaFjAVwdaAOJb9PHTo+E/rvmO0zuYc5okwbcGlAGvDXyFfYWEvdCR3eutG2RGq5ocscXtX3IHH6kh7xWToq4SAU2qImTvuNrkHxqbcAT+KSwZ+vpfFRI9DtMsqjXlEMlyVGaHoPaBFRvA7rCs89pQri2GaNMPBytk7t/dWNUhspkv8iqArnV2je/BzZ0DvOgU4hkZz590Bv9PvbeTpCXlUXRhAVl/2KLxSslcf79lYSlxKLJX5yMVASGV3hTNyA5Eg3aOoYx3ZIUJikuThjOqDeQ7xek5DxcyLWOz2UumcCL9VZsWarJ/R5XIKFA5Grf6J8wNzAfMAcGBSsOAwIaBBQACD3f3dvEqTjtfz45ye3G0xEyLgQUi8KiaJ+n7HLaBXvcsgElx0Is3r4=
END_OF_CERT

cat > "${INI_FILE}" <<END_OF_INIFILE
[parameters]
installcert=true
run_provision=true
relative_path=ini
ca_cert=ca.cer
cert=provisioning.pfx
ca_pwd=true
target=VFTRSWOM1
port=17778
ipaddress=195.87.1.20,::1,84.44.1.180
targetDeviceID=00000000-0000-0000-0000-000000000000
is_active=true
server_http_port=17790
proxy_access_type=disabled
proxy_username=XdLujE+whOuqhUTzlgdEbLv1cHfRRftX1FyHHAJuIflFm+wQCecuOj0bpJe8GePz/juLPSDYMAF1OBTQlPypaxDcGqBiVvuqRg4QIxr7wBr0NuGQ48ks9rZQ1Omkh4rb+GHKBW5MZdsNIw69FdQ01Th2FAEMLVZj9MYH5SrqnyFKv/YB3bOVRzQm0PCNcDmMCLawo7LKoblL4fHJKtmzu3rZyT8tyrKMv333xFrD/kedq4OTqndjLkN3Jps6jDpsIF2xMCBLpTtV+rXnxYyPAe4SmP9hlPaSp6nOTzNB7KqqJWrPA5w/bWhLPsxpmdInEOpeUSB3rvVCMbrxXEZ5tBopoWAQQbgBciQfsYU0cynFEWRg0WSHig4nFtJgFOtpSkoXVfORzbbRvU1jJtSfqQ+X6O4H/UCObKOA3Dfd8Y9uFUdfoT6qePeG831W00Me8sW7f9IVgdjWGOtg3Dpea5LzWLFHIAK8ZjBbeoK9AJKI8hQkFk7rdEzWkIa7wh2G
proxy_password=G7t6irj03URvIGD8+040kBpDLB8JkJGW7kU1eQVlCOR7gQBh9HEKtN44WimQb4RTc0JaCcJnUc70ewmHsuowKzKe+FCgnHAXS1vl0o5NproyMFsQuB+QarOBKnQdVKoUJkRDxuf3q6jczb/Xn6R1h31Qopj3hLvt9CtYRLWhCdHcYpHtaiZiKVWH/CM09LGGXlgEwciEbqV0BFTBWWVkx4Ri/+o02SSjKs8DB0b/JonuwDof9vNhuG/H3f2DVqD83A4vV3yz03rQqLUJVWjDwKd8Q3TTO4A52X/ssyNT79QenAAE2uYLXz6Dp7gCgneGLRl0Ez67nbYpXOTjDKa0VdInleFxJ1g3cnKFa0AQ3BT7lIaEsDMBGFqB65baq5QMb0AwI8E/PdV87XqUiNt+RlI4GQgaHyOAOpmbr2y82526OeE/nX5ovMDe+bdaDJt7FSZTSzA5d9VkiQILnM54qsG9pEyEPxObMOlCculh4p9ijSmGmRhwMeduzweZjnAx

END_OF_INIFILE

main
